using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
 




public class GameManager : MonoBehaviour
{

    public int MINSCORE;
    public const float WAITTIME = 0.5f;

    public GameObject EndingScreen;
    public static GameManager GM;
    
   
    public bool GameOver = false;

    public Text scoreText;
    public static int score;
    public static int highscore = 0;

    public Text pointsLeftText;

    private int actualScene;



    // Start is called before the first frame update
    void Start()
    {
        actualScene = SceneManager.GetActiveScene().buildIndex - 1;

        MINSCORE = MenuManager.minScores[actualScene];


        GM = this;
        GameOver = false;

        score = 0;
        

    }





    // Update is called once per frame
    void Update()
    {

        if (GameOver)
        {

            if (score > highscore)
            {
                highscore = score;

            }

            ScoreScreen();



        }

        scoreText.text = "� " + score.ToString();



    }

    public void OnClickMenuButton()
    {
        MenuManager.highScores[actualScene] = highscore;

        SceneManager.LoadScene(0);

    }

    public void OnClickReplayButton()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);

    }


    public void ScoreScreen()
    {
        string sentence = "points left for next level: ";
        int levelNumber = SceneManager.GetActiveScene().buildIndex + 1;


        EndingScreen.SetActive(true);


        if (MINSCORE > score)
        { 

        pointsLeftText.text = sentence + (MINSCORE - score).ToString();

        }
            
        else
        {
            pointsLeftText.text = sentence + 0 + "\n\nGratulation: Level " + levelNumber + " unlocked".ToString();



        }





        GameOver = false;

    }

  
    


}
