using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class MenuManager : MonoBehaviour
{
    public GameObject[] lockButton;
    public Text[] highscoreText;
    public static int[] minScores;

    public static int[] highScores;
   




    // Start is called before the first frame update
    void Start()
    {
        int numberOfScenes;
        int numberOfSucceededLevels;

        numberOfScenes = SceneManager.sceneCountInBuildSettings - 1;

        minScores = new int[numberOfScenes];
        highScores = new int[numberOfScenes];

        minScores[0] = 8000;

      
        numberOfSucceededLevels =  DeactivateLockButton();

        PrintHighScores(numberOfSucceededLevels);

        


       


    }

    

    // Update is called once per frame
    void Update()
    {
        


    }


    private int DeactivateLockButton()
    {
        int i;

        for (i = 0; i < minScores.Length; i++)
        {
            if (highScores[i] < minScores[i])
            {
                i++;

                return i;


            }

            Destroy(lockButton[i]);

        }

        

        return i;


    }

    public void PrintHighScores(int succeededLevels)
    {
        highscoreText = new Text[succeededLevels];

        for (int i = 0; i < succeededLevels; i++)
        {

            highscoreText[i].text = "�" + highScores[i].ToString();

        }


    }

    public void OnClickLevelOne()
    {
        SceneManager.LoadScene(1);
    }

    public void OnClickLevelTwo()
    {
        SceneManager.LoadScene(2);
    }


    public void DeleteProgress()
    {

        PlayerPrefs.DeleteAll();

    }





}
