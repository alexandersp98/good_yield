using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class destroyWall : MonoBehaviour
{
    private Rigidbody2D rb;
    public float wallStrength = 2f;
    public GameObject Container;




    // Start is called before the first frame update
    void Start()
    {
        rb = this.gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        



    }

    private void OnCollisionEnter2D(Collision2D collision)
    {


        if (rb.velocity.magnitude > wallStrength)
        {
            Destroy(gameObject);
        }

        if (collision.gameObject == Container)
        {
           

            Destroy(gameObject);


        }


    }
}
