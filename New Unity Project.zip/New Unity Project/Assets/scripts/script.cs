using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class script : MonoBehaviour
{
    public Rigidbody2D rb;
    public Rigidbody2D hook;
    public float nextShotTime = 3;
    public float releaseTime = 0.15f;
    public float maxDragDistance = 2f;
    public GameObject nextShotPrefab;
    public bool isPressed = false;


    public int shotsLeft = 0;
    public bool lastShot = false;


    


    // Start is called before the first frame update
    private void Start()
    {
        lastShot = false;
    }

    // Update is called once per frame
    void Update()
    {
        if (isPressed)
        {
            Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            if(Vector3.Distance(mousePos, hook.position) > maxDragDistance)
            {
                rb.position = hook.position + (mousePos - hook.position).normalized * maxDragDistance;
            }

            else
            {
                rb.position = mousePos;
            }




        }


        
    }

    private void OnMouseDown()
    {
        isPressed = true;
        rb.isKinematic = true;

    }

    private void OnMouseUp()
    {
        isPressed = false;
        rb.isKinematic = false;

        StartCoroutine(Release());

     

    }

    IEnumerator Release()
    {
        yield return new WaitForSeconds(releaseTime);

        GetComponent<SpringJoint2D>().enabled = false;
        this.enabled = false;



        if (nextShotPrefab != null)
        {
            yield return new WaitForSeconds(nextShotTime);

            nextShotPrefab.SetActive(true);
        }

        else
        {
            lastShot = true;
        }

        yield return new WaitForSeconds(releaseTime * 2);
        StartCoroutine(RemoveBird());



    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        
            StartCoroutine(RemoveBird());

        


    }


    IEnumerator RemoveBird()
    {
        yield return new WaitForSeconds(3.0f);
        Destroy(gameObject);

        if (lastShot)
        {
            if (GameManager.GM == null)
            {

            }

            else if (GameManager.GM.EndingScreen.activeSelf == true)
            {

            }

            else
            {
                GameManager.GM.GameOver = true;

            }



        }

    }

}
