namespace UnityEngine.Advertisements.Utilities
{
    internal static class Color
    {
        public const int Transparent = 0;
    }
}
