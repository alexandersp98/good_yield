# Known Issues

* **Contents of a ModalUtility window are invisible when launched from a Unity Context Menu on 2020.3LTS, 2021.1, and 2021.2 (Active).**

* **Enabling the Plastic SCM for Unity package disables the standard VCS integration option in the Project Settings.**
